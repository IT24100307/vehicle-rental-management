package com.system.project1.service;

import com.system.project1.entity.CustomerServiceStaff;
import com.system.project1.repository.CustomerServiceStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceStaffService {

    @Autowired
    private CustomerServiceStaffRepository repository;

    public CustomerServiceStaff saveStaff(CustomerServiceStaff staff) {
        return repository.save(staff);
    }

    public List<CustomerServiceStaff> getAllStaff() {
        return repository.findAll();
    }

    public CustomerServiceStaff getStaffById(String id) {
        return repository.findById(id).orElse(null);
    }

    public CustomerServiceStaff updateStaff(CustomerServiceStaff staff) {
        return repository.save(staff);
    }

    public void deleteStaff(String id) {
        repository.deleteById(id);
    }
}
