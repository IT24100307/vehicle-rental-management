package com.system.project1.controller;

import com.system.project1.entity.CustomerServiceStaff;
import com.system.project1.service.CustomerServiceStaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/staff")
public class CustomerServiceStaffController {

    @Autowired
    private CustomerServiceStaffService service;

    @PostMapping("/add")
    public CustomerServiceStaff addStaff(@RequestBody CustomerServiceStaff staff) {
        return service.saveStaff(staff);
    }

    @GetMapping("/all")
    public List<CustomerServiceStaff> getAllStaff() {
        return service.getAllStaff();
    }

    @GetMapping("/{id}")
    public CustomerServiceStaff getStaffById(@PathVariable String id) {
        return service.getStaffById(id);
    }

    @PutMapping("/update")
    public CustomerServiceStaff updateStaff(@RequestBody CustomerServiceStaff staff) {
        return service.updateStaff(staff);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteStaff(@PathVariable String id) {
        service.deleteStaff(id);
        return "Deleted staff with ID: " + id;
    }
}
